/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entrades;

import javax.swing.SwingUtilities;
import model.DadesEntrades;
import vista.AppView;

/**
 *
 * @author usuari
 */
public class EntradesMain {
public static void main(String[] args) {
        DadesEntrades model = new DadesEntrades();
        
        SwingUtilities.invokeLater(() -> {
            AppView appView = new AppView(model);
            appView.setVisible(true);
        });
    }
}
