package vista;



import javax.swing.*;
import model.DadesEntrades;

public class AppView extends JFrame {

    //atributs ha de rebre el model d'entrada

    public AppView(DadesEntrades model) {
        //actualització listener si el necessiteu
        //model de dades
        //opcions de finestra
        
        
        //carregar panell
        
        //crear menu


    }

    private void buildMenu() {

    }


}
