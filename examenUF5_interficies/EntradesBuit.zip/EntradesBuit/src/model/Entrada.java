package model;

import java.util.Objects;



public class Entrada {
    private String dni;
    private String nom;
    private String concert;
    //decidiu boolean o string
//    private boolean vip;
//    private String vip;

    // Constructor


    // Getters i Setters

    
    //Sobreescritura metodes necessaris

}
