package model;

public class DadesEntrades {
    //te que implementar la interface

        //Carregar dades Inicials Via codi, al constructor.




}
